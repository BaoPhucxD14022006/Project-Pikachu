import pygame
import os 
import sys
import json
import pandas as pd
import math
from functools import reduce

current_dir = os.path.dirname(os.path.abspath(__file__))
current_dir += '/RankScreen'

class OptionButton:
    def __init__(self, screen, x, y, w, h, text):
        self.x = x
        self.y = y
        self.w = w
        self.h = h
        self.screen = screen
        self.options = []
        self.text = text
        self.rect = pygame.Rect(self.x, self.y, self.w, self.h)
        self.is_open = False 
        self.result = None
        
    def add_option(self, option):
        if type(option) == str:
            self.options.append(option)
        else:
            self.options += list(option)
        
    def draw(self):
        border_color = (255, 215, 0)  
        border_width = 4  
        
        fill_color = (255, 255, 255)

        pygame.draw.rect(self.screen, border_color, self.rect, width=border_width)

        inner_rect = self.rect.inflate(-border_width, -border_width)  
        pygame.draw.rect(self.screen, fill_color, inner_rect)

        font_path = current_dir + '/font_pixel.otf'
        font = pygame.font.Font(font_path, 12)
        content = self.text + ' : ' + self.result if self.result else self.text
        text = font.render(content, True, (0, 0, 0))
        text_rect = text.get_rect(center=self.rect.center)
        self.screen.blit(text, text_rect)

        if self.is_open:
            option_y = self.y + self.h
            for option in self.options:
                option_rect = pygame.Rect(self.x, option_y, self.w, self.h)
                pygame.draw.rect(self.screen, (255, 255, 255), option_rect)
                option_text = font.render(option, True, (0, 0, 0))  
                self.screen.blit(option_text, (self.x + 10, option_y + 10)) 
                option_y += self.h 

    def handle_event(self, event):
        if event.type == pygame.MOUSEBUTTONDOWN:
            mouse_x, mouse_y = event.pos
            if self.rect.collidepoint(mouse_x, mouse_y):
                self.is_open = not self.is_open
                self.result = None
            elif self.is_open:
                option_y = self.y + self.h
                flag = None
                for option in self.options:
                    option_rect = pygame.Rect(self.x, option_y, self.w, self.h)
                    if option_rect.collidepoint(mouse_x, mouse_y):
                        flag = True
                        self.result = option
                        self.is_open = False
                    option_y += self.h
                if not flag:
                    self.is_open = False
    
class Button:
    def __init__(self, screen, x, y, path):
        self.path = path
        self.button = pygame.image.load(current_dir + '/' + self.path)
        self.screen = screen
        self.rect = pygame.Rect(x, y, self.button.get_width(), self.button.get_height())
        
    def draw(self):
        self.screen.blit(self.button, self.rect)
        
class RankScreen:
    def __init__(self):

        self.w_screen = 1000
        self.h_screen = 570
        self.screen = pygame.display.set_mode((self.w_screen , self.h_screen))
        self.icon = pygame.image.load(current_dir + '/icon.jpg') 
        pygame.display.set_icon(self.icon) 
        pygame.display.set_caption('Game PiKaChu')
        self.background = pygame.image.load(current_dir + '/rank_background.png') 
        self.running = True
        
        self.filter = {}
        self.option_size = OptionButton(self.screen, x=190, y=200, w=90, h=30, text='Size')
        self.option_size.add_option(['8x8', '9x16', '12x30'])
        self.filter['size'] = self.option_size.result
        self.option_gen = OptionButton(self.screen, x=315, y=200, w=90, h=30, text='Gen')
        self.option_gen.add_option(['Kanto', 'Joto'])
        self.filter['gen'] = self.option_gen.result
        self.option_level = OptionButton(self.screen, x=440, y=200, w=80, h=30, text='Level')
        self.option_level.add_option(['1', '2', '3', '4', '5'])
        self.filter['level'] = self.option_level.result
        self.option_device = OptionButton(self.screen, x=555, y=200, w=130, h=30, text='Device')
        self.option_device.add_option(['Mouse', 'KeyBoard'])
        self.filter['device'] = self.option_device.result
        self.options_button = [self.option_size,
                               self.option_gen,
                               self.option_level,
                               self.option_device]

        self.button_confirm = Button(self.screen, x=700, y=195, path='button_confirm.png')
        self.button_home = Button(self.screen, x=20, y=20, path='button_home.png')
        self.buttons = [self.button_confirm, self.button_home]
        self.table = Table(x_center=500, y_center=400, filter=self.filter, screen=self.screen)
        self.show_table = False
        self.page = Pagination(self.screen, self.table.max_page, (410, 615), (550, 615), 20)
        
    def update_filter(self):
        self.filter['size'] = self.option_size.result
        self.filter['gen'] = self.option_gen.result
        self.filter['level'] = self.option_level.result
        self.filter['device'] = self.option_device.result
        
    def handle_event(self):
        for event in pygame.event.get():
            for option_button in self.options_button:
                option_button.handle_event(event)
                self.draw()
            self.update_filter()
            if event.type == pygame.QUIT:
                pygame.quit()
                sys.exit()
            if event.type == pygame.MOUSEMOTION:
                mouse_pos = pygame.mouse.get_pos()
                for button in self.buttons:
                    if button.rect.collidepoint(mouse_pos):
                        button.button.set_alpha(100)
                    else:
                        button.button.set_alpha(255)
                    self.draw()
            if event.type == pygame.MOUSEBUTTONDOWN:
                mouse_pos = pygame.mouse.get_pos()
                if self.button_confirm.rect.collidepoint(mouse_pos):
                    self.update_filter()
                    self.table.filter = self.filter
                    self.table.update_data()
                    self.page.total_pages = self.table.max_page
                    self.page.current_page = 1
                    self.show_table = True
                    self.draw()
                if self.show_table:
                    if reduce(lambda x,y : x or y, [option_button.is_open for option_button in self.options_button]):
                        self.show_table = False
                if self.page.rect_prev.collidepoint(mouse_pos):
                    self.page.prev_page()
                    self.draw()
                if self.page.rect_next.collidepoint(mouse_pos):
                    self.page.next_page()
                    self.draw()
                if self.button_home.rect.collidepoint(mouse_pos):
                    self.running = False
                    print("HOME")
                    
    
    def run(self):
        self.draw()
        while self.running:
            self.handle_event()
            pygame.display.flip()
            
    
    def draw(self):
        self.screen.blit(self.background, (0, 0)) 
        for option_button in self.options_button:
            option_button.draw()
        for button in self.buttons:
            button.draw()
        if self.show_table:
            self.table.draw(page=self.page.current_page)
            self.page.draw()
            
            
class Table:
    def __init__(self, x_center, y_center, filter, screen):
        self.x_center = x_center
        self.y_center = y_center
        self.filter = filter
        self.screen = screen
        self.h_row = 30
        self.max_row = 10
        self.data, self.max_page = self.get_data()
        
    def check_game(self, game):
        for key in self.filter:
            if self.filter[key] is not None:
                if game[key] != self.filter[key]:
                    return False
        return True

    def get_data(self):
        with open(current_dir + '/' + 'rank.json', 'r') as file:
            data = json.load(file)
        data_dic = {}
        data_dic['namegame'] = []
        data_dic['user'] = []
        for key in self.filter:
            if self.filter[key] is None:
                data_dic[key] = []
        data_dic['score'] = []
        for namegame in data:
            if self.check_game(data[namegame]):
                data_dic['namegame'].append(namegame)
                data_dic['user'].append(data[namegame]['user'])
                data_dic['score'].append(data[namegame]['score'])
                for key in self.filter:
                    if self.filter[key] is None:
                        data_dic[key].append(data[namegame][key])
        df = pd.DataFrame(data_dic)
        df = df.sort_values(by='score', ascending=False)
        df = df.reset_index(drop=True)
        df.at[0, 'rank'] = 1
        for i in range(1, len(df)):
            if df.iloc[i]['score'] == df.iloc[i - 1]['score']:
                df.at[i, 'rank'] = df.at[i - 1, 'rank']
            else:
                df.at[i, 'rank'] = i + 1
        df['rank'] = df['rank'].astype(int)
        df['number'] = range(1, len(df) + 1)
        cols = ['number'] + [col for col in df.columns if col != 'number']
        df = df[cols]
        max_page = math.ceil(len(df) / self.max_row)
        return df, max_page

    def update_data(self):
        self.data, self.max_page = self.get_data()

    def draw(self, page=1):
        font_path = current_dir + '/font_pixel.otf'
        font = pygame.font.Font(font_path, 15)
        df = self.data[(page-1)*self.max_row:]
        if len(df) > self.max_row:
            df = df[:self.max_row]
        df = df.reset_index(drop=True)
        if not df.isna().any().any():
            column_names = df.columns.tolist()
            column_widths = self.calculate_column_widths(df)
            w_table = sum(column_widths)
            x_cell = self.x_center - w_table//2
            y_cell = self.y_center - self.max_row // 2 * self.h_row
            for i, col in enumerate(column_names):
                text_surface = font.render(col.title(), True, (0, 0, 0)) 
                text_rect = text_surface.get_rect(center=(x_cell + column_widths[i] / 2, y_cell + self.h_row / 2))
                self.screen.blit(text_surface, text_rect)
                x_cell += column_widths[i]
                
            x_cell = self.x_center - w_table//2
            y_cell = self.y_center - self.max_row // 2 * self.h_row + self.h_row
            for i in range(min(self.max_row, len(df))):
                for j, col in enumerate(df.columns):
                        text_surface = font.render(str(df.at[i, col]), True, (0, 0, 0))
                        text_rect = text_surface.get_rect(center=(x_cell + column_widths[j] / 2, y_cell + self.h_row / 2))
                        self.screen.blit(text_surface, text_rect)
                        x_cell += column_widths[j]
                x_cell = self.x_center - w_table//2
                y_cell += self.h_row
        else:
            text_surface = font.render(str('No matching results'), True, (0, 0, 0))
            text_rect = text_surface.get_rect(center=(self.x_center, self.y_center))
            self.screen.blit(text_surface, text_rect)      

    def calculate_column_widths(self, df):
        column_widths = []
        for col in df.columns:
            max_len = max(df[col].apply(lambda x: len(str(x))).max(), len(col))  
            max_len = max(max_len, len(col))
            column_widths.append(max_len * 15)  
        column_widths = [w + 5 for w in column_widths]
        return column_widths
    
class Pagination:
    def __init__(self, screen, total_pages, prev_button_pos, next_button_pos, size):
        self.current_page = 1
        self.total_pages = total_pages
        self.prev_button_pos = prev_button_pos
        self.rect_prev = pygame.Rect(prev_button_pos[0], prev_button_pos[1], size, size)
        self.next_button_pos = next_button_pos
        self.rect_next = pygame.Rect(next_button_pos[0], next_button_pos[1], size, size)
        self.size = size
        self.color = (0, 0, 255)
        self.text_color = (0, 0, 0)
        font_path = current_dir + '/font_pixel.otf'
        self.font = pygame.font.Font(font_path, 15)
        self.screen = screen

    def next_page(self):
        if self.current_page < self.total_pages:
            self.current_page += 1

    def prev_page(self):
        if self.current_page > 1:
            self.current_page -= 1

    def draw(self):
        prev_button = pygame.Rect(self.prev_button_pos[0], self.prev_button_pos[1], self.size, self.size)
        pygame.draw.polygon(self.screen, self.color, [(prev_button.centerx, prev_button.top), 
                                                  (prev_button.left, prev_button.centery), 
                                                  (prev_button.centerx, prev_button.bottom)])
        next_button = pygame.Rect(self.next_button_pos[0], self.next_button_pos[1], self.size, self.size)
        pygame.draw.polygon(self.screen, self.color, [(next_button.centerx, next_button.top), 
                                                  (next_button.right, next_button.centery), 
                                                  (next_button.centerx, next_button.bottom)])
        text = f"{self.current_page} of {self.total_pages}"
        text_surface = self.font.render(text, True, self.text_color)
        text_rect = text_surface.get_rect(center=((self.next_button_pos[0] - self.prev_button_pos[0] - self.size)//2 + self.prev_button_pos[0] + self.size,
                                self.next_button_pos[1] + self.size//2))
        self.screen.blit(text_surface, text_rect )


def main():
    pygame.init()
    rank = RankScreen()
    rank.run()