# Pikachu-Classic
Game Pikachu Classic
Link youtube của game: https://www.youtube.com/watch?v=OOvS2l1ruiQ&feature=youtu.be

Đây là game Pikachu mình tự code với thuật toán BFS advance có lưu lại đường đi, và thuật toán reset bảng khi không thể tìm được 2 con nối với nhau. Core của game chính là 2 thuật toán này, nếu bạn nào đọc code vẫn không hiểu thì có thể contact mình tại FB: https://www.facebook.com/ngovan.khoi.1
